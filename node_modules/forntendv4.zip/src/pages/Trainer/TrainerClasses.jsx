// 📄 TrainerClasses.jsx – Trainer's Class Management with Full CRUD Support
import { useEffect, useState } from 'react'
import { useUserStore } from '../../store/userStore'
import { AcademicCapIcon, PencilSquareIcon, TrashIcon, PlusCircleIcon } from '@heroicons/react/24/outline'

export default function TrainerClasses() {
  const { userId } = useUserStore()
  const [classes, setClasses] = useState([])
  const [loading, setLoading] = useState(true)
  const [editClass, setEditClass] = useState(null)
  const [title, setTitle] = useState('')
  const [scheduleDate, setScheduleDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [cost, setCost] = useState('')
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')

  const fetchClasses = async () => {
    const res = await fetch(`http://localhost:5000/api/training-classes?trainerId=${userId}`)
    const data = await res.json()
    setClasses(data)
    setLoading(false)
  }

  useEffect(() => { if (userId) fetchClasses() }, [userId])

  const handleAddClass = async (e) => {
    e.preventDefault()
    setError(''); setMessage('')
    if (!title || !scheduleDate || !endDate || !cost || !userId) return setError('Missing fields')
    try {
      const res = await fetch('http://localhost:5000/api/training-classes', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, scheduleDate, endDate, cost: parseFloat(cost), trainerId: userId })
      })
      if (!res.ok) throw new Error('Failed to add class')
      setTitle(''); setScheduleDate(''); setEndDate(''); setCost(''); setMessage('Class added')
      fetchClasses()
    } catch (err) {
      setError(err.message)
    }
  }

  const handleUpdate = async () => {
    try {
      const res = await fetch(`http://localhost:5000/api/training-classes/${editClass.id}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editClass)
      })
      if (!res.ok) throw new Error('Update failed')
      setEditClass(null)
      fetchClasses()
    } catch (err) {
      alert(err.message)
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this class?')) return
    await fetch(`http://localhost:5000/api/training-classes/${id}`, { method: 'DELETE' })
    fetchClasses()
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <AcademicCapIcon className="w-8 h-8 text-indigo-400" /> Manage Training Classes
        </h1>

        {/* List */}
        {loading ? <p>Loading...</p> : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {classes.map(cls => (
              <div key={cls.id} className="bg-white/10 p-4 rounded-xl border border-indigo-400">
                <h2 className="text-xl font-semibold text-indigo-200">{cls.title}</h2>
                <p className="text-sm text-gray-300">🗓️ Start: {new Date(cls.startDate).toLocaleDateString()}</p>
                <p className="text-sm text-gray-300">🗓️ End: {new Date(cls.endDate).toLocaleDateString()}</p>
                <p className="text-sm text-gray-300">💰 Cost: ${cls.cost}</p>
                <div className="flex gap-2 mt-3">
                  <button onClick={() => setEditClass(cls)} className="text-indigo-300 hover:underline"><PencilSquareIcon className="w-5 h-5 inline" /> Edit</button>
                  <button onClick={() => handleDelete(cls.id)} className="text-red-400 hover:underline"><TrashIcon className="w-5 h-5 inline" /> Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleAddClass} className="bg-white/5 p-6 rounded-xl space-y-4">
          <h3 className="text-xl font-semibold flex items-center gap-2"><PlusCircleIcon className="w-5 h-5 text-green-400" /> Add New Class</h3>
          <input value={title} onChange={e => setTitle(e.target.value)} type="text" placeholder="Class Title" className="w-full p-2 rounded bg-gray-800 text-white" />
          <input value={scheduleDate} onChange={e => setScheduleDate(e.target.value)} type="date" className="w-full p-2 rounded bg-gray-800 text-white" />
          <input value={endDate} onChange={e => setEndDate(e.target.value)} type="date" className="w-full p-2 rounded bg-gray-800 text-white" />
          <input value={cost} onChange={e => setCost(e.target.value)} type="number" placeholder="Cost" className="w-full p-2 rounded bg-gray-800 text-white" />
          <button type="submit" className="w-full bg-indigo-500 py-2 rounded">Add Class</button>
          {error && <p className="text-red-400 text-sm">{error}</p>}
          {message && <p className="text-green-400 text-sm">{message}</p>}
        </form>

        {/* Edit Modal */}
        {editClass && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 z-50">
            <div className="bg-white text-black p-6 rounded-xl shadow-lg w-full max-w-md space-y-4">
              <h3 className="text-xl font-semibold">Edit Class</h3>
              <input value={editClass.title} onChange={e => setEditClass({ ...editClass, title: e.target.value })} className="w-full border p-2 rounded" />
              <input type="date" value={editClass.scheduleDate?.split('T')[0]} onChange={e => setEditClass({ ...editClass, scheduleDate: e.target.value })} className="w-full border p-2 rounded" />
              <input type="date" value={editClass.endDate?.split('T')[0]} onChange={e => setEditClass({ ...editClass, endDate: e.target.value })} className="w-full border p-2 rounded" />
              <input type="number" value={editClass.cost} onChange={e => setEditClass({ ...editClass, cost: e.target.value })} className="w-full border p-2 rounded" />
              <div className="flex justify-end gap-2">
                <button onClick={() => setEditClass(null)} className="px-4 py-2 rounded bg-gray-200">Cancel</button>
                <button onClick={handleUpdate} className="px-4 py-2 rounded bg-indigo-600 text-white">Update</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
