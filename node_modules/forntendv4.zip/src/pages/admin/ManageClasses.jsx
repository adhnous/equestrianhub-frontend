// 📄 ManageClasses.jsx – Fully Functional with Edit Support and 2-Column Layout
import { useEffect, useState } from 'react';
import { useUserStore } from '../../store/userStore';
import {
  TrashIcon,
  PlusCircleIcon,
  ArrowRightIcon,
  PencilSquareIcon,
  XMarkIcon
} from '@heroicons/react/24/outline';

export default function ManageClasses() {
  const { logout } = useUserStore();
  const [classes, setClasses] = useState([]);
  const [trainers, setTrainers] = useState([]);
  const [trainees, setTrainees] = useState([]);
  const [newClass, setNewClass] = useState({
    title: '', description: '', startDate: '', endDate: '', cost: '', trainerId: ''
  });
  const [editingClass, setEditingClass] = useState(null);

  const fetchAllData = async () => {
    try {
      const [clsRes, trainerRes, traineeRes] = await Promise.all([
        fetch('http://localhost:5000/api/training-classes'),
        fetch('http://localhost:5000/api/trainers'),
        fetch('http://localhost:5000/api/trainees')
      ]);
      const [clsData, trainerData, traineeData] = await Promise.all([
        clsRes.json(), trainerRes.json(), traineeRes.json()
      ]);
      setClasses(clsData);
      setTrainees(traineeData);
      setTrainers(trainerData);
    } catch (err) {
      console.error('Failed to load data:', err);
    }
  };

  const handleUpdate = async () => {
    try {
      const res = await fetch(`http://localhost:5000/api/training-classes/${editingClass.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingClass)
      });
      if (!res.ok) throw new Error('Update failed');
      setEditingClass(null);
      fetchAllData();
    } catch (err) {
      console.error('Update error:', err);
    }
  };

  const handleDelete = async (id) => {
  const confirmed = window.confirm('Are you sure you want to delete this class?');
  if (!confirmed) return;
  try {
    const res = await fetch(`http://localhost:5000/api/training-classes/${id}`, {
      method: 'DELETE'
    });
    if (!res.ok) throw new Error('Failed to delete class');
    setClasses(prev => prev.filter(cls => cls.id !== id));
  } catch (err) {
    console.error('Error deleting class:', err);
  }
};

  useEffect(() => { fetchAllData(); }, []);

  const getTrainerName = (id) => trainers.find(t => t.id === id)?.name || 'Unassigned';
  const getTrainerSpec = (id) => trainers.find(t => t.id === id)?.specialty || 'N/A';
  const getTraineeNames = (ids) => trainees.filter(t => ids.includes(t.id)).map(t => `${t.username} (${t.level})`);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8 pb-4 border-b border-gray-700">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
            Training Class Manager
          </h1>
          <button onClick={logout} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700">
            <span className="text-amber-400">Logout</span>
            <ArrowRightIcon className="w-4 h-4 text-amber-400" />
          </button>
        </div>

        {/* Class Form */}
        <div className="mb-8 bg-gray-800 rounded-xl p-6 shadow-lg">
          <h2 className="text-xl font-semibold mb-6 text-amber-400">{editingClass ? 'Edit Class' : 'Add New Class'}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <input type="text" placeholder="Title" className="p-3 rounded bg-gray-700 text-white" value={(editingClass || newClass).title} onChange={e => (editingClass ? setEditingClass({ ...editingClass, title: e.target.value }) : setNewClass({ ...newClass, title: e.target.value }))} />
            <input type="text" placeholder="Description" className="p-3 rounded bg-gray-700 text-white" value={(editingClass || newClass).description} onChange={e => (editingClass ? setEditingClass({ ...editingClass, description: e.target.value }) : setNewClass({ ...newClass, description: e.target.value }))} />
            <input type="number" placeholder="Cost" className="p-3 rounded bg-gray-700 text-white" value={(editingClass || newClass).cost} onChange={e => (editingClass ? setEditingClass({ ...editingClass, cost: e.target.value }) : setNewClass({ ...newClass, cost: e.target.value }))} />
            <input type="date" className="p-3 rounded bg-gray-700 text-white" value={(editingClass || newClass).startDate} onChange={e => (editingClass ? setEditingClass({ ...editingClass, startDate: e.target.value }) : setNewClass({ ...newClass, startDate: e.target.value }))} />
            <input type="date" className="p-3 rounded bg-gray-700 text-white" value={(editingClass || newClass).endDate} onChange={e => (editingClass ? setEditingClass({ ...editingClass, endDate: e.target.value }) : setNewClass({ ...newClass, endDate: e.target.value }))} />
            <select className="p-3 rounded bg-gray-700 text-white" value={(editingClass || newClass).trainerId} onChange={e => (editingClass ? setEditingClass({ ...editingClass, trainerId: e.target.value }) : setNewClass({ ...newClass, trainerId: e.target.value }))}>
              <option value="">Select Trainer</option>
              {trainers.map(t => (<option key={t.id} value={t.id}>{t.name}</option>))}
            </select>
          </div>
          <div className="flex justify-end gap-4">
            {editingClass ? (
              <>
                <button onClick={() => setEditingClass(null)} className="px-4 py-2 rounded bg-gray-600 hover:bg-gray-500 text-white flex gap-2 items-center">
                  <XMarkIcon className="w-4 h-4" /> Cancel
                </button>
                <button onClick={handleUpdate} className="px-6 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded font-semibold flex items-center gap-2">
                  <PencilSquareIcon className="w-5 h-5" /> Update Class
                </button>
              </>
            ) : (
              <button onClick={() => handleAdd()} className="w-full py-3 rounded bg-amber-500 hover:bg-amber-600 text-white font-semibold flex items-center justify-center gap-2">
                <PlusCircleIcon className="w-5 h-5" /> Create Class
              </button>
            )}
          </div>
        </div>

        {/* Classes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {classes.map(cls => (
            <div key={cls.id} className="bg-gray-800 rounded-xl p-6 shadow-md">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-2xl font-bold text-amber-400">{cls.title}</h3>
                  <p className="text-gray-300 mb-2">{cls.description}</p>
                  <p className="text-sm text-gray-400 mb-1">💰 Cost: ${cls.cost}</p>
                  <p className="text-sm text-gray-400 mb-1">👤 Trainer: {getTrainerName(cls.trainerId)} ({getTrainerSpec(cls.trainerId)})</p>
                  <p className="text-sm text-gray-400 mb-2">📅 {new Date(cls.startDate).toLocaleDateString()} → {new Date(cls.endDate).toLocaleDateString()}</p>
                  {cls.enrolledTrainees && (
                    <div className="text-sm text-gray-300">
                      👥 Enrolled:
                      <ul className="list-disc ml-6">
                        {getTraineeNames(cls.enrolledTrainees).map((t, i) => <li key={i}>{t}</li>)}
                      </ul>
                    </div>
                  )}
                </div>
                <div className="flex flex-col items-end gap-2">
                  <button onClick={() => setEditingClass(cls)} className="p-2 text-amber-400 hover:bg-amber-500/20 rounded">
                    <PencilSquareIcon className="w-6 h-6" />
                  </button>
                  <button onClick={() => handleDelete(cls.id)} className="p-2 text-red-400 hover:bg-red-500/20 rounded">
                    <TrashIcon className="w-6 h-6" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
