
import { useEffect, useState } from 'react'
import { PlusCircleIcon, XCircleIcon } from '@heroicons/react/24/outline'

export default function AssignHorsesToCompetitions() {
  const [competitions, setCompetitions] = useState([])
  const [horses, setHorses] = useState([])
  const [selectedUserRole, setSelectedUserRole] = useState('trainee')
  const [selectedUserId, setSelectedUserId] = useState('')
  const [selectedHorseId, setSelectedHorseId] = useState('')

  const fetchAllData = async () => {
    try {
      const [compRes, horseRes] = await Promise.all([
        fetch('http://localhost:5000/api/competitions'),
        fetch('http://localhost:5000/api/horses')
      ])
      setCompetitions(await compRes.json())
      setHorses(await horseRes.json())
    } catch (err) {
      alert('Failed to load data')
    }
  }

  useEffect(() => {
    fetchAllData()
  }, [])

  const assignHorse = async (competitionId) => {
    if (!competitionId || !selectedUserId || !selectedUserRole || !selectedHorseId) {
      return alert('All fields required')
    }
    try {
      const res = await fetch(`http://localhost:5000/api/competitions/${competitionId}/horses/assign-to-user`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ horseId: selectedHorseId, userId: selectedUserId, userRole: selectedUserRole })
      })
      const result = await res.json()
      alert(result.message)
      fetchAllData()
    } catch (err) {
      alert('Failed to assign')
    }
  }

  const unassignHorse = async (competitionId, horseId, userId) => {
    try {
      const res = await fetch(`http://localhost:5000/api/competitions/${competitionId}/horses/unassign-from-user`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ horseId, userId })
      })
      const result = await res.json()
      alert(result.message)
      fetchAllData()
    } catch (err) {
      alert('Failed to unassign')
    }
  }

  const userCompetitions = competitions.filter(c =>
    [...(c.Trainees || []), ...(c.Trainers || [])].some(u => u.id === selectedUserId)
  )

  const availableCompetitions = competitions.filter(c =>
    ![...(c.Trainees || []), ...(c.Trainers || [])].some(u => u.id === selectedUserId)
  )

  return (
    <div className="min-h-screen bg-yellow-50 p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-6">Assign Horses to Users in Competitions</h1>

        {/* Selection Panel */}
        <div className="bg-white p-4 rounded-lg shadow-md mb-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <select onChange={e => { setSelectedUserRole(e.target.value); setSelectedUserId('') }} className="p-2 border rounded-md">
            <option value="trainee">Trainee</option>
            <option value="trainer">Trainer</option>
          </select>

          <select onChange={e => setSelectedUserId(e.target.value)} className="p-2 border rounded-md">
            <option value=''>Select User</option>
            {competitions.flatMap(c => selectedUserRole === 'trainee' ? c.Trainees || [] : c.Trainers || [])
              .reduce((unique, u) => unique.find(i => i.id === u.id) ? unique : [...unique, u], [])
              .map(u => (
                <option key={u.id} value={u.id}>{u.name}</option>
              ))}
          </select>

          <select onChange={e => setSelectedHorseId(e.target.value)} className="p-2 border rounded-md">
            <option value=''>Select Horse</option>
            {horses.map(h => (
              <option key={h.id} value={h.id}>{h.name}</option>
            ))}
          </select>
        </div>

        {/* Your Competitions */}
        <h2 className="text-2xl font-semibold text-gray-700 mb-2">Your Competitions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-10">
          {userCompetitions.map(c => (
            <div key={c.id} className="border border-yellow-300 rounded-lg p-4 bg-white shadow-md">
              <h3 className="text-lg font-semibold text-yellow-700 mb-2">{c.name} 🏆</h3>
              <p className="text-sm text-gray-500">{c.location} 📍 | {new Date(c.date).toISOString().slice(0, 10)} 📅</p>
              <p className="text-sm text-gray-500">Type: {c.type}</p>

              {/* Assigned Horses */}
              {(c.CompetitionHorseAssignments || []).filter(a => a.userId === selectedUserId).map(a => {
                const horse = horses.find(h => h.id === a.horseId)
                return horse ? (
                  <div key={a.id} className="mt-2 flex justify-between items-center text-sm text-gray-700">
                    🐎 {horse.name}
                    <button onClick={() => unassignHorse(c.id, horse.id, selectedUserId)} className="text-red-500 hover:text-red-700 text-xs">
                      Unassign ❌
                    </button>
                  </div>
                ) : null
              })}

              {(c.CompetitionHorseAssignments || []).filter(a => a.userId === selectedUserId).length === 0 && (
                <p className="text-sm italic text-gray-400 mt-2">No horses assigned yet.</p>
              )}

              {/* Assign Button */}
              <button
                onClick={() => assignHorse(c.id)}
                disabled={!selectedHorseId || !selectedUserId}
                className="mt-4 w-full bg-yellow-400 hover:bg-yellow-500 text-white font-semibold py-1.5 rounded-md"
              >
                Assign Horse 🐎
              </button>
            </div>
          ))}
        </div>

        {/* Available Competitions (display only) */}
        <h2 className="text-2xl font-semibold text-gray-700 mb-2">Available Competitions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {availableCompetitions.map(c => (
            <div key={c.id} className="border border-gray-300 rounded-lg p-4 bg-white shadow-sm">
              <h3 className="text-lg font-semibold text-gray-800 mb-2">{c.name} 🐎</h3>
              <p className="text-sm text-gray-500">{c.location} 📍 | {new Date(c.date).toISOString().slice(0, 10)} 📅</p>
              <p className="text-sm text-gray-500">Type: {c.type}</p>
              <p className="text-sm italic text-gray-400 mt-4">User must join this competition from their own dashboard.</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
