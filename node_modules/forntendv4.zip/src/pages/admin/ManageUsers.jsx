// 📄 ManageUsers.jsx – Enhanced, Modernized Version with Purple Theme and Full CRUD
import { useEffect, useState } from 'react'
import { FaSpinner, FaUserPlus, FaTrash, FaEdit, FaUsersCog } from 'react-icons/fa'

export default function ManageUsers() {
  const [users, setUsers] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [editingUser, setEditingUser] = useState(null)
  const [newUser, setNewUser] = useState({
    name: '', email: '', password: '', role: 'trainee', gender: 'female', age: '', level: 'beginner', specialty: ''
  })

  const fetchUsers = async () => {
    setIsLoading(true)
    try {
      const res = await fetch('http://localhost:5000/api/admin/users')
      const data = await res.json()
      setUsers(data)
    } catch (err) {
      console.error('Failed to fetch users:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const getEndpoint = (role) => ({ admin: 'admins', trainer: 'trainers', trainee: 'trainees' }[role] || 'users')

  const handleAddUser = async () => {
    if (!newUser.name || !newUser.email || !newUser.password) {
      alert('Please fill in all required fields')
      return
    }
    setIsSaving(true)

    const payload = {
      trainee: { ...newUser, age: Number(newUser.age), role: 'trainee' },
      trainer: { ...newUser, role: 'trainer' },
      admin: { username: newUser.name, email: newUser.email, password: newUser.password, role: 'admin' }
    }[newUser.role]

    try {
      const res = await fetch(`http://localhost:5000/api/${getEndpoint(newUser.role)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })

      if (!res.ok) throw new Error('Failed to create user')

      alert('✅ User created successfully!')
      setNewUser({ name: '', email: '', password: '', role: 'trainee', gender: 'female', age: '', level: 'beginner', specialty: '' })
      fetchUsers()
    } catch (err) {
      alert(err.message)
    } finally {
      setIsSaving(false)
    }
  }

  const handleDelete = async (user) => {
    if (!window.confirm(`Are you sure you want to delete ${user.name || user.username}?`)) return
    try {
      const res = await fetch(`http://localhost:5000/api/${getEndpoint(user.role)}/${user.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Failed to delete user')
      fetchUsers()
    } catch (err) {
      alert('Error: ' + err.message)
    }
  }

  const handleUpdateUser = async () => {
    try {
      const res = await fetch(`http://localhost:5000/api/${getEndpoint(editingUser.role)}/${editingUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingUser)
      })
      if (!res.ok) throw new Error('Failed to update user')
      setEditingUser(null)
      fetchUsers()
    } catch (err) {
      alert('Update failed: ' + err.message)
    }
  }

  useEffect(() => { fetchUsers() }, [])

  return (
    <div className="min-h-screen bg-purple-100 p-8">
      <div className="max-w-6xl mx-auto bg-white shadow-lg rounded-xl p-6">
        <h1 className="text-3xl font-bold text-purple-800 flex items-center gap-3 mb-6">
          <FaUsersCog className="text-purple-500" />
          User Management
        </h1>

        {/* Create User Form */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <input placeholder="Name" className="input border-purple-300" value={newUser.name} onChange={e => setNewUser({ ...newUser, name: e.target.value })} />
          <input placeholder="Email" className="input border-purple-300" value={newUser.email} onChange={e => setNewUser({ ...newUser, email: e.target.value })} />
          <input placeholder="Password" type="password" className="input border-purple-300" value={newUser.password} onChange={e => setNewUser({ ...newUser, password: e.target.value })} />
          <select className="input border-purple-300" value={newUser.role} onChange={e => setNewUser({ ...newUser, role: e.target.value })}>
            <option value="trainee">Trainee</option>
            <option value="trainer">Trainer</option>
            <option value="admin">Admin</option>
          </select>
          {newUser.role !== 'admin' && (
            <select className="input border-purple-300" value={newUser.gender} onChange={e => setNewUser({ ...newUser, gender: e.target.value })}>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          )}
          {newUser.role === 'trainee' && (
            <>
              <input placeholder="Age" type="number" className="input border-purple-300" value={newUser.age} onChange={e => setNewUser({ ...newUser, age: e.target.value })} />
              <select className="input border-purple-300" value={newUser.level} onChange={e => setNewUser({ ...newUser, level: e.target.value })}>
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </>
          )}
          {newUser.role === 'trainer' && (
            <input placeholder="Specialty" className="input border-purple-300" value={newUser.specialty} onChange={e => setNewUser({ ...newUser, specialty: e.target.value })} />
          )}
        </div>

        <button onClick={handleAddUser} className="btn bg-purple-500 hover:bg-purple-600 text-white flex items-center gap-2" disabled={isSaving}>
          {isSaving ? <FaSpinner className="animate-spin" /> : <FaUserPlus />} Create User
        </button>

        {/* Users Cards */}
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            <FaSpinner className="animate-spin mx-auto text-4xl text-purple-500" />
          ) : (
            users.map(user => (
              <div
                key={user.id}
                className={`rounded-xl p-4 shadow hover:shadow-md border relative
                  ${user.role === 'trainee' ? 'bg-green-50 border-green-200 text-green-800' : ''}
                  ${user.role === 'trainer' ? 'bg-blue-50 border-blue-200 text-blue-800' : ''}
                  ${user.role === 'admin' ? 'bg-yellow-50 border-yellow-300 text-yellow-800' : ''}`}
              >
                <h3 className="text-xl font-bold mb-1">{user.name || user.username}</h3>
                <p className="text-sm">📧 {user.email}</p>
                <p className="text-sm capitalize">👤 Role: {user.role}</p>
                {user.gender && <p className="text-sm">🚻 Gender: {user.gender}</p>}
                {user.level && <p className="text-sm">🎓 Level: {user.level}</p>}
                {user.specialty && <p className="text-sm">📚 Specialty: {user.specialty}</p>}
                {user.age && <p className="text-sm">🎂 Age: {user.age}</p>}
                <div className="flex gap-2 mt-2">
                  <button onClick={() => setEditingUser(user)} className="text-indigo-600 hover:underline text-sm">Edit</button>
                  <button onClick={() => handleDelete(user)} className="text-red-600 hover:underline text-sm">Delete</button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Edit Modal */}
        {editingUser && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 z-50">
            <div className="bg-white p-6 rounded-xl w-full max-w-md shadow-lg space-y-4">
              <h3 className="text-xl font-semibold text-gray-800">Edit User</h3>
              <input
                type="text"
                className="w-full border p-2 rounded"
                value={editingUser.name || editingUser.username}
                onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value, username: e.target.value })}
              />
              <input
                type="email"
                className="w-full border p-2 rounded"
                value={editingUser.email}
                onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
              />
              <div className="flex justify-end gap-2">
                <button onClick={() => setEditingUser(null)} className="px-4 py-2 rounded bg-gray-200 hover:bg-gray-300 text-gray-800">Cancel</button>
                <button onClick={handleUpdateUser} className="px-4 py-2 rounded bg-indigo-600 hover:bg-indigo-700 text-white">Update</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
